************************************************************************************************
Thank you for downloading this asset pack!
************************************************************************************************

A part from the black cards, cards are split into two part: the value (0,1,..,9) + the +2 card and the color base.
To use it you simply need to put the value on top of the color base. 




<<<IMPORTANT: UNO is a copyrighted licences so be carefull of the way you use those asset>>>